# Renderer Next Steps Spec
**Title:** Local Asset Pinning + Private IPFS Gateway + 3‑Phase Warmup + “Fresh” Revalidation  
**Project:** RMRK Renderer (Base / Kanaria / Chunkies)  
**Date:** 2026‑01‑24  
**Audience:** Core renderer maintainers + infra/ops + marketplace integrators

---

## 0. Executive summary

You’re seeing two classes of failures under real marketplace load:

- **RPC throttling / transient reverts** when many token renders are requested concurrently.
- **IPFS gateway 502/504 timeouts** while fetching part SVGs / token assets on demand.

Even though the renderer already caches **some** assets and renders to disk, the runtime path still depends on *live* upstreams (RPC + IPFS gateways) frequently enough that a marketplace grid view can overwhelm the system.

This spec proposes a pragmatic, ops‑light architecture that makes the renderer increasingly self‑sufficient after an initial warmup:

1. **Pinned local asset store** (no eviction) for IPFS‑addressed content.
2. **Private local “IPFS gateway” endpoint** (localhost only) that serves pinned assets so the renderer can stop hitting external gateways once it has the file.
3. **3‑phase warmup** that (A) fully pins catalog + referenced assets, (B) walks token IDs to discover and pin token‑specific assets, and (C) optionally pre‑renders popular sizes.
4. **Simple cache revalidation** with a *long* “checked within” window (1 day), plus a `?fresh=1` override that forces a re-check but is **rate‑limited per IP** (1 per 5 minutes).

Outcome: normal marketplace/wallet traffic gets stable, cached images, while anyone can force “most recent on‑chain state” with `?fresh=1` without manual timestamp management.

---

## 1. Goals and non‑goals

### Goals

- **Reduce third‑party reliance** during normal renders: once an asset is fetched once, serve it locally forever.
- **Stable default UX** for marketplaces/wallets (fast image loads, low variance).
- **One obvious “up to date” path**: a user or marketplace can request a `?fresh=1` URL to re-check state and get the newest render.
- **3‑phase warmup** with:
  - Throttling, retries, and progress reporting.
  - Admin status endpoints that report % completion.
  - Ability to manually enqueue specific token IDs for warmup.
- **No public IPFS exposure**: the local gateway is for renderer-internal use only.

### Non‑goals

- Building a public IPFS gateway service for the internet.
- Perfect “instant” cache busting for *all* consumers without any revalidation trigger. (We’ll prioritize stability + explicit refresh.)
- Replacing the entire existing caching system in one go; this is an incremental overlay.

---

## 2. Current behavior (as of the latest archive)

### Render caching (summary)

- Render outputs are cached when a **cache timestamp** is present (explicit `?cache=` or derived from collection cache_epoch / default timestamp).
- Without a cache timestamp, responses can degrade to `Cache-Control: no-store`, which makes marketplaces retry and keeps pressure on upstreams.
- Render keys include a fingerprint that changes with on‑chain composition, but computing it typically requires RPC calls.

### Warmup today (summary)

- Warmup is a token range loop that **renders** tokens and caches the rendered result when a cache timestamp is resolved.
- Warmup is not explicitly “asset-only”; it can incidentally pull some assets, but it does not guarantee:
  - catalog completion,
  - token asset coverage,
  - or persistent pinning behavior.

### Asset caching today (summary)

- Assets fetched over IPFS gateways are cached on disk with a TTL and may be size‑managed/evicted.
- Under load, the renderer can still issue many concurrent gateway requests before caches are “settled,” and can still be forced to re-fetch when assets are missing, evicted, or never successfully downloaded.

---

## 3. Proposed architecture

### 3.1 Pinned asset store

Introduce a **pinned store** distinct from the current “cache”:

- **Pinned store**: never evicted; survives restarts; keyed by canonical (CID + path).
- **Cache store**: current behavior (may be evicted); used for derived artifacts like rasterized SVG, resized outputs, etc.

Pinned store becomes the “source of truth” for IPFS files once fetched.

#### Disk layout

A safe, simple layout that handles both *CID roots* and *CID subpaths*:

- `PINNED_DIR/ipfs/<cid>/__root__` for `ipfs://<cid>`
- `PINNED_DIR/ipfs/<cid>/<path>` for `ipfs://<cid>/<path>`

Rules:
- Normalize `path` and **reject traversal** (`..`, absolute paths, backslashes).
- Create directories as needed.

We also store metadata (DB) for:
- content type,
- size,
- first_seen_at / pinned_at,
- last_error / attempts.

### 3.2 Private local IPFS gateway endpoint

Add an internal HTTP gateway that serves pinned assets using standard gateway paths:

- `GET http://127.0.0.1:<LOCAL_IPFS_PORT>/ipfs/<cid>`
- `GET http://127.0.0.1:<LOCAL_IPFS_PORT>/ipfs/<cid>/<path>`

This gateway is:
- **bound to localhost only** (127.0.0.1),
- **not reachable externally**,
- used by the renderer by prepending it to `IPFS_GATEWAYS` (first in list).

If the pinned file exists → 200 and bytes returned.  
If not pinned → 404 quickly → renderer falls back to remote gateways.

Why an HTTP gateway instead of direct file reads?
- It slots into the current gateway failover path with minimal disruption.
- It keeps the “asset fetch” path uniform (gateway list) and simplifies future tooling.

### 3.3 Token state caching + `fresh` revalidation

To reduce RPC load:
- Persist a **token state snapshot** in DB.
- Only re-check on chain:
  - once per day (configurable), OR
  - when `?fresh=1` is requested.

#### Revalidation policy

- `TOKEN_STATE_CHECK_TTL_SECONDS = 86400` (1 day default).
- `?fresh=1` bypasses TTL and forces a state re-check.
- `?fresh=1` is **rate-limited per NFT URL**: 1 per 5 minutes across all incoming IPs. This means 5 different marketplaces calling for a refresh in the span of a minute still only does one refresh in a 5 minute block.
- there should an admin control for allowing always-fresh-call to some clients, so that we can allow more frequent refreshes to specific customers, like games. This should be API-key gated so we can generate them an API key and ?fresh calls with that API key always cause a re-check and re-render+re-cache if new (this new state (if any) is, however, applied for everyone of course).

**Important:** `?fresh=1` should update DB even if we respond with `Cache-Control: no-store`. The point is *state refresh*, not caching that specific URL.

### 3.4 Three‑phase warmup

Warmup becomes a job system with explicit phases and progress.

#### Phase A — Catalog + catalog assets (must reach 100%)

For a collection:
1. Fetch catalog metadata (and base resource definitions if needed).
2. Enumerate all parts and the asset URIs they reference (fixed + slot visuals, gem slots, etc.).
3. Download all referenced IPFS files into pinned store.
4. Report completion percentage:
   - `catalog_parts_total`
   - `catalog_assets_total`
   - `catalog_assets_pinned`
   - `catalog_assets_failed`
   - and derived `%`.

This phase is the foundation: the shared assets used by many tokens should never hit gateways after Phase A.

#### Phase B — Token scan (asset discovery + pinning)

For a collection:
1. Iterate token IDs sequentially (admin supplies start/end; optional discovery helper).
2. For each token:
   - fetch on-chain composition (active asset, equips, children)
   - resolve all metadata URIs
   - resolve all part SVG/PNG URIs that will ever be needed for that token’s render plan
   - pin those assets to disk
3. Track token progress:
   - tokens scanned / total target
   - assets discovered
   - assets pinned
   - failures

Admin controls:
- “Warm token IDs” endpoint: queue specific tokens (for gaps/outliers).
- “Resume / Pause / Stop” jobs.
- “Retry failed assets” action.

#### Phase C — Render warmup (optional)

After Phase A+B:
- Optionally pre-render certain widths/formats for a subset or full range.
- This keeps the existing warmup behavior, but now it runs **without upstream dependencies** (because assets are pinned and token state is cached).

Phase C is optional because:
- it consumes CPU,
- and the main win is removing external fetches.

---

## 4. Data model changes (DB)

Add new tables (names illustrative):

### 4.1 `pinned_assets`
Tracks the pinned store status per canonical IPFS key.

Columns:
- `id` (pk)
- `asset_key` (unique) — canonical `ipfs://<cid>/<path>` string
- `cid` (indexed)
- `path` (indexed)
- `content_type`
- `size_bytes`
- `status` enum: `pinned | missing | failed`
- `attempts`
- `last_error`
- `first_seen_at`
- `pinned_at`
- `last_attempt_at`

### 4.2 `collection_asset_refs`
The set of assets required by a collection (catalog-driven).

- `collection_key` (chain+collection)
- `asset_key`
- unique(collection_key, asset_key)

### 4.3 `token_asset_refs`
The set of assets required by a token (token-driven discovery).

- `collection_key`
- `token_id`
- `asset_key`
- unique(collection_key, token_id, asset_key)

### 4.4 `token_state_cache`
Stores last-known state to avoid repeated RPC checks.

- `collection_key`
- `token_id`
- `state_hash` (hash of relevant on-chain state)
- `state_json` (optional; includes active asset, equips, children, theme)
- `last_checked_at`
- `last_checked_block` (optional)
- `expires_at` (derived)
- `last_error`
- unique(collection_key, token_id)

### 4.5 `warmup_jobs` + `warmup_job_items` (queue)
Replace or extend existing warmup state tracking.

- jobs: id, type, params, status, created_at, updated_at, next_run_at
- items: id, job_id, key (asset_key or token_id), status, attempts, last_error

---

## 5. API and admin UX requirements

### 5.1 New admin endpoints (examples)

**Collection warmup**
- `POST /admin/warmup/catalog`  
  body: { chain, collection, force: bool }
- `POST /admin/warmup/tokens`  
  body: { chain, collection, start_token, end_token, step, force: bool }
- `POST /admin/warmup/tokens/manual`  
  body: { chain, collection, token_ids: [..] }

**Status**
- `GET /admin/warmup/status?chain=...&collection=...`
  returns:
  - phase statuses (A/B/C),
  - % pinned,
  - remaining counts,
  - last errors,
  - ETA is optional (not required).

**Control**
- `POST /admin/warmup/pause?id=...`
- `POST /admin/warmup/resume?id=...`
- `POST /admin/warmup/cancel?id=...`
- `POST /admin/warmup/retry_failed?id=...`

### 5.2 Required admin UX elements

- Collection page shows:
  - Catalog pinned % and token scan %.
  - Current running job + last errors.
  - Button: “Warm catalog”
  - Button: “Warm token range”
  - Input: “Warm specific token IDs”

---

## 6. Render request semantics

### 6.1 Query params

- `fresh=1`  
  Forces a state re-check (subject to rate limit).
- Existing `cache`/`cache_timestamp` remains supported for compatibility.

### 6.2 Default behavior (no params)

1. Look up `token_state_cache`.
2. If **not present** or **expired** (older than 1 day):
   - refresh state via RPC (singleflight per token)
   - update `token_state_cache`.
3. Use state to compute render plan & fingerprint.
4. Load assets from pinned store (via local gateway first).
5. Render if not cached; cache output.
6. Return image with long-lived cache headers.

### 6.3 Fresh behavior

If `fresh=1`:
- enforce rate limit as defined above
- force state refresh now.
- update `token_state_cache` (so subsequent *normal* requests get newest).
- return image. (Can be `no-store` to ensure the request always re-checks.)

**Note:** Even if we serve `no-store`, we should still write the newly rendered output to the renderer cache for the canonical (non-fresh) URL path.

---

## 7. Background worker design

### 7.1 Worker loops

Run N async workers (configurable) that pull due items from `warmup_job_items`, respecting:

- `MAX_CONCURRENT_RPC_CALLS`
- `MAX_CONCURRENT_IPFS_FETCHES`
- per-collection throttles (avoid “one collection eats all bandwidth”)
- exponential backoff on 429/502/504 from gateways

### 7.2 Retry/backoff policy

- For gateway 504/502:
  - rotate gateway
  - backoff: 2s, 4s, 8s, … max 5 minutes
  - cap attempts (e.g., 10) then mark `failed` until manual retry
- For RPC -32016 rate limit:
  - backoff with jitter and rotate RPC endpoints if available
- Persist errors (don’t spam logs only).

---

## 8. Config additions

Suggested env vars (names illustrative):

- `PINNED_DIR=/data/pinned`
- `LOCAL_IPFS_ENABLED=true`
- `LOCAL_IPFS_BIND=127.0.0.1`
- `LOCAL_IPFS_PORT=18180`
- `TOKEN_STATE_CHECK_TTL_SECONDS=86400`
- `FRESH_RATE_LIMIT_SECONDS=300` (5 minutes)
- `FRESH_RATE_LIMIT_BURST=1`
- `WARMUP_MAX_CONCURRENT_ASSET_PINS=4` (separate from runtime)
- `WARMUP_MAX_CONCURRENT_TOKEN_SCANS=2`

---

## 9. Implementation plan (milestones)

### Milestone 1 — Pinned asset store + local gateway
- Add pinned store directories and DB table.
- Implement local gateway listener (localhost only).
- Put local gateway first in `IPFS_GATEWAYS`.
- Ensure `AssetManager` records asset_key → pinned status.
- Add admin endpoint to query pinned asset count.

**Acceptance:** For a pinned asset, renderer never contacts remote gateways again.

#### Milestone 1 implementation notes (Phase 1 — 2026‑01‑24)
- ✅ Added pinned store + `pinned_assets` table + counts query (`src/pinning.rs`, `src/db.rs`).
- ✅ Added `PINNING_ENABLED`, `PINNED_DIR`, and local gateway envs; local gateway is prepended to `IPFS_GATEWAYS` when enabled (`src/config.rs`, `env.example`).
- ✅ Local gateway server bound to loopback only and started alongside main app (`src/local_ipfs.rs`, `src/main.rs`).
- ✅ Asset resolver pins IPFS bytes + records DB; it also checks pinned store before remote fetches to enforce “no remote once pinned” (`src/assets.rs`).
- ✅ Admin endpoint `/admin/api/pinned` returns pinned counts (`src/admin.rs`).

Rationalizations:
- Local gateway bind failures are logged and do not abort startup; pinned reads still bypass gateways via direct file reads.
- Direct pinned reads are included to guarantee the “no remote once pinned” acceptance even if the local gateway is disabled or fails to bind.

### Milestone 2 — Phase A catalog warmup
- Implement catalog enumeration and asset key extraction.
- Queue asset pin jobs for every catalog part.
- Add progress reporting endpoints + admin UI.

**Acceptance:** Catalog warmup reaches 100% for Kanaria without manual retries.

#### Milestone 2 implementation notes (Phase 2 — 2026‑01‑24)
- ✅ Added catalog warmup queue tables + asset ref table; stored `catalog_address` in collection config (`src/db.rs`).
- ✅ Catalog part enumeration uses on-chain `AddedPart` events (`src/chain.rs`).
- ✅ Catalog warmup worker pins part metadata + assets and records pin failures (`src/catalog_warmup.rs`, `src/db.rs`, `src/pinning.rs`).
- ✅ Renderer stores catalog address from `compose_equippables` for reuse (`src/render.rs`).
- ✅ Added `WARMUP_MAX_CONCURRENT_ASSET_PINS` config + env example (`src/config.rs`, `env.example`).
- ✅ Added admin endpoints + UI for catalog warmup + status (`src/admin.rs`, `src/admin.js`).
- ✅ Added tests for catalog warmup DB flows + IPFS URI parsing (`src/db.rs`, `src/pinning.rs`).
- ✅ CI checks passed locally: `cargo fmt --check`, `cargo clippy --all-targets --all-features`, `cargo test` (only vendor warnings).

Rationalizations:
- Part discovery is event-driven (`AddedPart`) to avoid relying on catalog metadata schemas or token scans for Phase A.
- Catalog warmup shares the global pause toggle to keep operational controls simple.
- Slot parts that intentionally omit fallback artwork are treated as “skipped” rather than failures to avoid blocking 100% completion.

### Milestone 3 — Phase B token scan warmup (asset-only)
- Add token scanning job that stores token asset refs and pins assets.
- Add manual token enqueue endpoint.

**Acceptance:** After scanning a range, rendering those tokens does not hit IPFS gateways.

#### Milestone 3 implementation notes (Phase 3 — 2026‑01‑24)
- ✅ Added token warmup jobs/items + `token_asset_refs` with counts helpers (`src/db.rs`).
- ✅ Token warmup worker scans token compositions, resolves metadata (thumb + full), and pins assets (`src/token_warmup.rs`).
- ✅ Admin endpoints + UI for token range and manual token warmup (`src/admin.rs`, `src/admin.js`).
- ✅ Added tests for token warmup DB flows (`src/db.rs`).
- ✅ CI checks passed locally: `cargo fmt --check`, `cargo clippy --all-targets --all-features`, `cargo test` (only vendor warnings).

Rationalizations:
- Token scans resolve both thumbnail and full asset URIs to avoid `prefer_thumb` misses during renders.
- Non-composable assets fall back to static asset metadata so token scans still pin required bytes.

### Milestone 4 — Token state caching + `fresh`
- Add `token_state_cache` table + access layer.
- Implement “checked within 1 day” logic.
- Implement `fresh` parameter and per-IP limiter.

**Acceptance:** Marketplace grid loads do not trigger per-image RPC calls (except on expiry/fresh).

#### Milestone 4 implementation notes (Phase 4 — 2026‑01‑24)
- ✅ Added token state cache + fresh limiter tables and DB helpers (`src/db.rs`).
- ✅ Render pipeline now uses cached token state with singleflight refresh and stores fallback flags (`src/render.rs`, `src/state.rs`).
- ✅ Implemented `fresh` query param, no-store responses, and per-NFT cooldown with API-key bypass (`src/http.rs`, `src/admin.rs`, `src/admin.js`).
- ✅ Added `TOKEN_STATE_CHECK_TTL_SECONDS` + `FRESH_RATE_LIMIT_SECONDS` config + env example, plus OpenAPI updates (`src/config.rs`, `env.example`, `openapi.yaml`).
- ✅ Added tests for token state cache + fresh limiter (`src/db.rs`).
- ✅ CI checks passed locally: `cargo fmt --check`, `cargo clippy --all-targets --all-features`, `cargo test` (only vendor warnings).

Rationalizations:
- Token state cache is keyed by chain/collection/token/asset and stores `fallback_used` so multi‑asset tokens and non‑composable fallbacks don’t cross‑pollinate cache policy.
- Fresh limiter is persisted in SQLite to enforce the “one refresh per NFT URL” rule across all IPs and restarts; client keys can opt‑out via `allow_fresh`.

### Milestone 5 — Phase C optional render warmup
- Keep current render warmup as optional job type.
- Ensure it uses pinned assets and cached token state.

**Acceptance:** Pre-rendering 512px thumbnails for a collection completes without upstream calls.

#### Milestone 5 implementation notes (Phase 5 — 2026‑01‑24)
- ✅ Render warmup is labeled as Phase C optional in admin UI and uses cached token state (`src/admin.rs`, `src/warmup.rs`).
- ✅ Added marketplace list-view simulator script to stress render/cache behavior (`scripts/marketplace-sim.ts`).
- ✅ Added render output capture script for saving rendered images by token (`scripts/render-output.ts`).
- ✅ Added hash replacement support so admins can upload a static image for missing IPFS CIDs via the Admin UI (`src/admin.rs`, `src/admin.js`, `src/assets.rs`, `src/db.rs`).
- ✅ Hash replacement validated by uploading a PNG for CID `QmXaU5G4...`; renders for tokens 86/184/198/215/251 completed successfully with no IPFS timeouts.

Rationalizations:
- Phase C stays optional to avoid unnecessary CPU usage while still supporting pre-rendered thumbnails when needed.
- Load simulation is kept in a standalone script to exercise production-like traffic without altering runtime code paths.

### Milestone 6 — Hardening + docs
- Update README with:
  - recommended ops flow (approve → warm A → warm B → optionally warm C)
  - expected disk sizing
  - how to use `?fresh=1`
- Add “failure log” and “warmup status” troubleshooting section.

#### Milestone 6 implementation notes (Phase 6 — 2026‑01‑24)
- ✅ Updated README with ops flow, disk sizing guidance, `?fresh=1` usage, and Phase A/B/C commands (`README.md`).
- ✅ Added troubleshooting details for failure logs and warmup status, plus local prod smoke test steps (`README.md`).
- ✅ Fixed local IPFS wildcard route to avoid Axum runtime panic (`src/local_ipfs.rs`).
- ✅ Added asset URI normalization (data URIs, bare CID/CID-path IPFS, sanitized HTTP URLs) and oversized raster resizing caps (`src/assets.rs`, `env.example`).
- ✅ Token warmup now skips invalid/empty asset URIs instead of failing items, while still pinning valid assets (`src/token_warmup.rs`, `src/assets.rs`).
- ✅ Invalid asset URI failures are auto-classified as done during token warmup finalization to keep jobs green (`src/token_warmup.rs`, `src/db.rs`).
- ✅ Added relative asset URI resolution (HTTP/IPFS base) and `ar://` normalization to `https://arweave.net/` (`src/assets.rs`).
- ✅ HTTP gateway IPFS URLs are normalized to `ipfs://` so gateway rotation applies; render-utils top-asset lookup falls back to `getTopAssetAndEquippableDataForToken` (`src/assets.rs`, `src/chain.rs`).
- ✅ CI checks passed locally: `cargo fmt --check`, `cargo clippy --all-targets --all-features`, `cargo test` (only vendor warnings).
- ✅ Local prod-style smoke test (port 8105, `PINNED_DIR=./pinned-test16`, `LOCAL_IPFS_ENABLED=false`):
  - Catalog warmup started and pinned assets; token warmup completed for tokens 1–50 with 0 failures.
  - Sample metadata CID entries (`QmUU8ab...`, `QmUBDMY...`) only contain `external_url`/`externalUri` (no renderable media), so they are unfixable and remain logged as “no renderable asset.”
  - Render warmup queued successfully.
  - Marketplace simulation via `scripts/marketplace-sim.ts` returned cache hits with low latency.
 - Wider warmup run (port 8107, tokens 1–100) left 5 failures:
   - 67/80/92: RPC rate limit (`-32016`) from base.org.
   - 86: IPFS CID `QmXaU5G4...` missing/timeout across gateways (504 ipfs.io, 404 filebase).
   - 87: render-utils call reverted with data `0x3456866f` (top asset unavailable).
- ✅ Added fallback handling for `0x89ba7e10` (compose-equippables revert) as non-composable in warmup/render; contract reverts now fall back to `tokenURI` and skip if the token URI itself reverts (`src/token_warmup.rs`, `src/render.rs`).
- ✅ Revert detection now also handles `execution reverted` messages for tokenURI/top-asset calls, preventing false failures when providers return that wording (`src/token_warmup.rs`, `src/chain.rs`, `src/render.rs`).
- ✅ RPC rate-limit errors disappeared when forcing Alchemy-only endpoints (port 8119, `RPC_ENDPOINTS` set to the Alchemy URL); confirms base.org was the source of `-32016` fallback errors.
- ✅ Alchemy-only warmup results:
  - Tokens 1–100: only token 86 failed (IPFS CID `QmXaU5G4...` still unreachable across gateways).
  - Tokens 101–200: tokens 184/198 failed on the same IPFS CID `QmXaU5G4...`; token 173 no longer failed after handling `execution reverted`.
  - Tokens 201–300: tokens 215/251 failed on the same IPFS CID `QmXaU5G4...`; render outputs saved to `pinned-test32/outputs` with 98/100 images generated.
  - Multi-collection render capture (port 8122, `PINNED_DIR=./pinned-test33`):
    - `0x7d5f40...` tokens 1–150: warmup 0 failures; 150/150 renders saved to `pinned-test33/outputs/0x7d5f40...`.
    - `0x011ff4...` tokens 1–150: warmup failures 67 (tokenURI revert `0x89ba7e10`) + 86 (CID `QmXaU5G4...` timeout); renders saved 134/150 (tokens 67/87/92 HTTP 500; remaining failures timed out).
    - `0xb30b90...` tokens 1–150: warmup 0 failures; 150/150 renders saved to `pinned-test33/outputs/0xb30b90...`.
- Debugged `0xb30b90...` missing-skin issue when equipped (tokens 6/7):
  - Slot children now always render at the slot’s z. Background child stays at z=0, so the fixed skin at z=1 remains visible.
  - Child layer ordering is renderer policy (spec does not define child z), so per-collection overrides are the safest fix.
  - Global defaults remain unchanged to avoid shifting child placement for collections authored against the current behavior.
  - Overrides are now manageable via Admin UI and stored in DB; they take precedence over env `COLLECTION_RENDER_OVERRIDES`.
  - Debug logs via `DEBUG_RENDER_TOKENS`/`DEBUG_RENDER_COLLECTIONS`; sample renders saved to `pinned-test37/outputs`.

Rationalizations:
- Centralizing ops guidance in README reduces onboarding time and aligns operators on the phased warmup flow.

---

## 10. Testing strategy

- Unit tests:
  - asset key normalization
  - path traversal rejection
  - local gateway 404 vs 200 behavior
  - per-IP fresh limiter
- Integration tests:
  - run warmup A+B for Kanaria (approved)
  - request 100 random renders and assert:
    - zero external IPFS calls after warmup
- Load test:
  - simulate 200 concurrent render requests for a grid view (see `scripts/marketplace-sim.ts`).
  - verify upstream call rate stays bounded.

---

## 11. Rollout & safety

- Feature flags:
  - `LOCAL_IPFS_ENABLED`
  - `PINNING_ENABLED`
  - `TOKEN_STATE_CACHE_ENABLED`
- Rollout order:
  1) pinned assets + gateway (safe, additive)
  2) catalog warmup
  3) token warmup
  4) state cache TTL + fresh limiter

---

## 12. Notes for marketplace integrators

- Default image URLs will be stable and heavily cacheable.
- To force “latest state” after equip, request the same URL with `?fresh=1`.
  - If the marketplace adds a “refresh metadata” button, it can use `?fresh=1`.
  - If it receives 429, it should wait and retry.

---

End of spec.
