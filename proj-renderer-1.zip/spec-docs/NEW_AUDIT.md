## Audit report (team-of-five, tie‑breaker lead synthesis)

### Scope & method

Static, line-by-line review of the `proj-renderer` Rust service (Axum) plus the included Solidity contract (`solidity/RendererApprovals.sol`). I did not run `cargo test` or `cargo audit` in this environment (tooling not available here), so this is a “code + architecture” audit rather than a dynamic fuzz/pen-test.

What you already did well (worth keeping):

* **SSRF + unsafe fetch hardening**: HTTP fetches are pinned to resolved IPs, private IP ranges are blocked, redirects are disabled, and you cap bytes and pixels in multiple layers. This is unusually solid for renderer infra.
* **Global load-shedding**: `ConcurrencyLimitLayer`, `render_semaphore`, optional render queue, and per-key concurrency limits are a strong foundation against CPU-saturation.
* **Operational ergonomics**: `/status`, warmup system, cache eviction tasks, and a decent admin UI with CSP.

Below are the issues and recommendations consolidated by the lead after reconciling the 5 reviewers.

---

# 1) Security expert findings

## P0 / High-risk: “Approval-check amplification” can DDoS your RPC providers

**Where:** `render.rs::ensure_collection_approved()` → `on_demand_approval_check()`

**Attack:** In approval-required mode, **unknown collections** (no DB config) trigger an **on-demand onchain call** unless they’re in the negative cache. An attacker can send requests for a large number of random collection addresses (valid-looking) to:

* churn the negative cache (capacity is finite),
* force repeated on-demand RPC calls,
* saturate `rpc_semaphore`,
* degrade service for legitimate renders.

Even with per-IP rate limiting, a distributed actor can still do real damage because the “unit cost per request” includes RPC.

**Fix options (recommended order):**

1. **Hard gate on-demand approval checks**:

   * Only allow on-demand checks when the request is authenticated with a valid API key OR comes from allowlisted IP ranges.
   * Otherwise, treat unknown collections as unapproved without RPC.
2. **Add a separate “unknown collection on-demand check limiter”**:

   * Token bucket keyed by `ip` and/or `identity_key`, much stricter than render rate limits.
3. **Increase negative cache capacity and TTL** (band-aid, not primary defense).
4. **Make on-demand checks opt-in** (e.g., `?check=1`) for internal workflows.

This also aligns with your new “unapproved fallback asset” upsell: if registration is the intended funnel, you don’t want to burn RPC on every random probe.

**Resolution (2026-01-26):** Status: Implemented. On-demand approval checks are gated via `ApprovalCheckContext` and only allowed for authenticated API keys or allowlisted IPs in `access_middleware`. Unknown-collection checks are rate-limited with `IdentityRateLimiter` and new env limits (`APPROVAL_ON_DEMAND_RATE_LIMIT_PER_MINUTE` / `APPROVAL_ON_DEMAND_RATE_LIMIT_BURST`). Negative approval cache defaults were raised (`APPROVAL_NEGATIVE_CACHE_SECONDS=3600`, `APPROVAL_NEGATIVE_CACHE_CAPACITY=50000`). Justification: blocks unauthenticated probes from triggering RPC, caps remaining abuse per identity, and reduces cache churn.

---

## P1 / Medium: `/status` and `/openapi.yaml` may be reachable in Open mode even when “not public”

**Where:** `http.rs::is_public_landing_path()` and `access_middleware()`

If `ACCESS_MODE=open`, then **everything** except `/admin/api/*` effectively becomes accessible regardless of `status_public/openapi_public`. So `status_public=false` doesn’t mean “private”, it only means “not *explicitly* public” in the early bypass.

**Fix:**

* Treat `/status`, `/status.json`, and `/openapi.yaml` like:

  * “public only when enabled”
  * otherwise **admin-only** (or at least API-key-only)

**Resolution (2026-01-26):** Status: Implemented. `access_middleware` now enforces private access for `/status`, `/status.json`, and `/openapi.yaml` when `status_public` / `openapi_public` are false, and the README documents this behavior. Justification: prevents open-mode bypass of privacy flags.

---

## P2 / Low: API keys in query string

**Where:** `access_middleware()` accepts `?key=...`

This is a known security footgun (leaks into logs, referrers). If you keep it:

* default it off via config,
* or make it “only allowed over HTTPS + for specific clients”.

**Resolution (2026-01-26):** Status: Implemented. Query-string auth was removed; only `Authorization: Bearer` is accepted, and README documents that query keys are unsupported. Justification: avoids leaking credentials via logs or referrers.

---

## P2 / Low: Admin hardening headers

Admin has strong CSP, but you should also add:

* `X-Content-Type-Options: nosniff`
* `Permissions-Policy: ...` (tight)
* `Cross-Origin-Opener-Policy`/`Cross-Origin-Resource-Policy` (optional)

**Resolution (2026-01-26):** Status: Implemented. Added `X-Content-Type-Options: nosniff`, `Permissions-Policy`, `Cross-Origin-Opener-Policy`, and `Cross-Origin-Resource-Policy` in `admin_security_headers`. Justification: aligns admin responses with recommended hardening.

---

## Dependency risk note (action required)

You should run `cargo audit` in CI. RustSec recommends it as the standard approach. ([rustsec.org][1])
Your dependency tree includes multiple `hyper` versions (0.14 and 1.x), but the known historical request-smuggling issue affected older hyper ranges; you’re above those. ([nvd.nist.gov][2])

Also, keep an eye on RustSec advisories over time; RustSec is the canonical database. ([GitHub][3])

**Resolution (2026-01-26):** Status: Implemented. CI now runs `cargo audit` on PRs and scheduled runs via `.github/workflows/ci.yml`. Justification: ensures RustSec advisories are checked automatically.

---

# 2) Performance expert findings

## P0 / High: Cache-variant limiter is effectively broken (variant explosion → disk churn + eviction storms)

**Where:** `render.rs` around storing cached render → `render_cache_limiter.register(...)`

You *intend* to cap `MAX_CACHE_VARIANTS_PER_KEY`, but the limiter key passed includes the **full variant key** (including the fingerprinted variant key), which makes each variant effectively its own “bucket”, so `max_variants_per_key` never bites.

**Impact:**

* Attackers (or legitimate traffic with lots of `bg=` combinations) can cause massive numbers of cache files per token.
* Eviction becomes dominated by directory scans + delete churn.
* If `max_cache_size_bytes` is high or 0, you can fill disk.

**Fix:**

* Change the limiter grouping key to exclude the differentiator you want to cap. Practically:

  * Group by `(chain, collection, token_id, asset_id, base_size_key, extension)`
  * Do **not** include fingerprint or background/overlay if you want to cap those.
* Store “entry metadata” (at least last-access timestamp) if you want LRU behavior beyond insertion order.

This is the single biggest “real-world performance + DoS surface” issue I found.

**Resolution (2026-01-26):** Status: Implemented. `render_cache_limiter.register` now uses a base cache key that excludes overlay/background/fingerprint variance, so `MAX_CACHE_VARIANTS_PER_KEY` actually caps variants. Justification: prevents unbounded cache fan-out and eviction storms.

---

## P1: Stop reading whole cached render files into memory

**Where:** `render.rs::render_token_cached()` reads into `Vec<u8>`

For big throughput, it’s better to serve cached responses by streaming:

* `tokio::fs::File` + `ReaderStream` into response body,
* preserve `Content-Length` via metadata.

This avoids allocating per request and reduces tail latency under load.

**Resolution (2026-01-26):** Status: Not implemented. Cached renders are still read into memory in `render_token_cached`. Justification: requires a response-body streaming refactor; deferred to a follow-up change.

---

## P1: Lock contention hot paths

* `RateLimiter` uses a `Mutex<HashMap<...>>`
* `RenderSingleflight` and several caches are mutexed
* `KeyRenderLimiter` uses a mutexed map

You already have global concurrency limits, so contention might not be catastrophic, but at scale it will show up.

**Fix direction:**

* Prefer `dashmap` or sharded maps for high-frequency counters.
* Keep mutex-based caches, but ensure they’re bounded and have low critical-section work.

**Resolution (2026-01-26):** Status: Implemented. Hot-path maps (`RateLimiter`, `KeyRateLimiter`, `IdentityRateLimiter`, `RenderSingleflight`, `KeyRenderLimiter`) were migrated to `DashMap` with atomic cleanup tracking. Justification: reduces mutex contention under concurrent load.

---

## P2: Cache size scans are expensive

`cached_sizes()` and eviction walks are “disk scan” operations. You already TTL-cache these values, but if scrape/poll frequency increases (especially once Grafana is in play), you must ensure:

* metrics don’t force frequent scans,
* scans run in background with low priority and bounded frequency.

**Resolution (2026-01-26):** Status: Not changed. Existing TTL-cached scans remain; no new metrics scanning behavior introduced. Justification: defer until metrics load profile is known.

---

# 3) UX expert findings (humans + bots/agents)

## P0: Unapproved collection returns JSON error → broken images; fix is your new feature

Right now, marketplaces get JSON and show broken thumbnails. Your “unapproved fallback asset” is an immediate conversion win.

**UX details to bake in:**

* Fallback image should include:

  * “Collection not approved”
  * short CTA: “Register at renderer.rmrk.app”
  * optionally the chain + collection address in small text (helps developers)
* Add headers that bots can read:

  * `X-Renderer-Fallback: unapproved`
  * `X-Renderer-Fallback-Reason: approval_required`

**Resolution (2026-01-26):** Status: Implemented. Unapproved collections return a fallback image with CTA text, optional chain/collection label, and headers `X-Renderer-Fallback` / `X-Renderer-Fallback-Reason` plus `X-Renderer-Error-Code` and `X-Request-Id`. Response status is `200` to avoid broken thumbnails. Justification: improves marketplace UX while signaling bots.

## P1: Error responses should be bot-friendly by default

For automated clients:

* standardize error payload: `code`, `message`, `retry_after_seconds` when applicable
* add `X-Renderer-Error-Code` header even on JSON errors
* add `X-Request-Id` header for correlation (also log it)

**Resolution (2026-01-26):** Status: Implemented. `ApiError` now includes `code` in JSON plus `X-Renderer-Error-Code`, `X-Request-Id` is attached to all responses, and rate-limit responses include `retry_after_seconds`. Justification: standardizes machine-readable errors and correlation.

## P2: Reduce “perceived latency”

Even when render is slow:

* immediately return cached placeholder/“processing” image for requests that are queued (optional)
* or implement “fast 202 + location” for API clients (not for marketplaces)

Given your product, I’d keep current 503 queue behavior but add a **distinct fallback image** for “queued” if you want UX polish.

**Resolution (2026-01-26):** Status: Implemented (optional). Queue-full responses now have a distinct fallback image while keeping `503` and `Retry-After`. Justification: improves UX without changing API semantics.

---

# 4) DX expert findings

## P1: Clarify access-mode semantics in docs

Currently:

* open mode effectively makes `/status` reachable unless special-cased,
* `status_public` isn’t “privacy”; it’s “explicit bypass”.

Document this clearly or change behavior (recommended change: admin-only when not public).

**Resolution (2026-01-26):** Status: Implemented. Behavior changed to enforce privacy for `/status` and `/openapi.yaml`, and README clarifies access-mode semantics. Justification: removes ambiguity and aligns docs with behavior.

## P1: Make “how to add a feature” easier for a new team

This code is already pretty LLM-friendly. To push it over the edge:

* Add `ARCHITECTURE.md`: request flow diagram + caches + queues.
* Add a `DEVELOPMENT.md`: run, env vars, typical workflows (approve collection, warmup, debug render).
* Add a “module boundary” note:

  * `render` should stay pure-ish (no HTTP),
  * `http` decides response modes and fallbacks,
  * `admin` owns mutations and invalidations.

**Resolution (2026-01-26):** Status: Implemented. Added `ARCHITECTURE.md` and `DEVELOPMENT.md`, including module boundaries and request flow notes. Justification: reduces onboarding and clarifies ownership.

## P2: Add CI hooks

* `cargo fmt`, `clippy`
* `cargo audit` (RustSec)
* minimal smoke test: start server, hit `/healthz`

**Resolution (2026-01-26):** Status: Implemented. CI already runs fmt/clippy/tests; added `cargo audit` and a `/healthz` smoke test in `.github/workflows/ci.yml`. Justification: automated security + runtime sanity checks.

---

# 5) Edge case master findings

## P0: Variant-explosion via `bg=` + limiter bug

This is the “obvious after you see it” one:

* attacker varies `bg=#RRGGBB` and forces unique cache paths
* limiter doesn’t cap
* disk churn + eviction storms

This intersects **security + performance**.

**Resolution (2026-01-26):** Status: Implemented. Same fix as cache-variant limiter above; base cache key now caps `bg=`/overlay variants. Justification: closes variant-explosion path.

## P1: Unbounded `fresh_requests` table growth

**Where:** `db.rs::check_fresh_request()`

An attacker can generate many unique `(chain, collection, token, asset)` combinations with `fresh=1`, producing a lot of DB rows over time.

**Fix:**

* Add periodic cleanup: delete rows older than `N` days/hours.
* Or store only hashed keys and enforce a max row count with eviction.

**Resolution (2026-01-26):** Status: Implemented. Added `prune_fresh_requests` in `db.rs` and a periodic cleanup task in `main.rs`, configured by `FRESH_REQUEST_RETENTION_DAYS`. Justification: prevents unbounded table growth.

## P1: Metrics label cardinality (future feature risk)

If you expose Prometheus metrics labeled by:

* raw IP
* raw collection
  …a malicious actor can create infinite label values, and **Prometheus will die**.

So the metrics spec must explicitly bound cardinality (I include that below).

**Resolution (2026-01-26):** Status: Partially addressed. Added explicit guidance in `ARCHITECTURE.md` to avoid high-cardinality labels; no Prometheus metrics shipped yet. Justification: preempts future misuse.

---

# Tie‑breaker lead: prioritized fix list

### Ship-blockers / do these first (P0)

1. **Fix render cache variant limiter keying** (prevents cache explosion + DoS surface).
2. **Gate or limit on-demand approval checks** to prevent RPC amplification attacks.
3. When implementing Prometheus, **avoid high-cardinality labels** (no raw IP labels in Prometheus).

### Next (P1)

4. Stream cached render responses (reduce allocations under load).
5. Make `/status` and `/openapi.yaml` truly private when configured.
6. Add cleanup job for `fresh_requests` table.

### Later (P2/P3)

7. Admin security headers polish.
8. DX docs + CI automation.
9. Optional “queued” UX fallback.

**Resolution summary (2026-01-26):**

1. Implemented (base cache key limits variants).
2. Implemented (gated + rate-limited approval checks).
3. Documented guidance only (metrics not yet implemented).
4. Not implemented (cached response streaming pending).
5. Implemented (private status/openapi enforcement).
6. Implemented (fresh_requests pruning).
7. Implemented (admin hardening headers).
8. Implemented (ARCHITECTURE.md, DEVELOPMENT.md, CI audit/smoke).
9. Implemented (queued fallback image for queue full).

---
[1]: https://rustsec.org/?utm_source=chatgpt.com "About RustSec › RustSec Advisory Database"
[2]: https://nvd.nist.gov/vuln/detail/CVE-2021-21299?utm_source=chatgpt.com "CVE-2021-21299 - NVD"
[3]: https://github.com/rustsec/advisory-db?utm_source=chatgpt.com "rustsec/advisory-db: Security advisory database for Rust ..."
