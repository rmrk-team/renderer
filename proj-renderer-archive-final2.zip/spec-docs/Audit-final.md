## Audit scope and ground rules

**Scope reviewed (static code audit):**

* Rust server (`src/*`), including render pipeline, caching, access control, admin UI, landing page handling, and approval sync.
* Solidity contract (`solidity/RendererApprovals.sol`).
* `openapi.yaml` + `spec-docs/*` (including FIX3 context).

**Not done here:** dynamic penetration testing, fuzzing, load testing, or dependency vulnerability scanning (e.g., `cargo audit`). Those are still recommended as part of release hardening.

---

## Executive summary from the tie‑breaker lead

This codebase is in a strong place for production: the architecture is coherent, the render pipeline is defensive, and the operational knobs (limits, caches, gating) are unusually well thought out for an MVP renderer.

### What looks solid

* **SSRF hardening is strong**: URL validation + block internal/private ranges + no redirects + DNS pinning is a very good pattern, and aligns with OWASP SSRF guidance. ([OWASP Cheat Sheet Series][1])
* **Path traversal protection** for landing/static assets is intentional and multi-layered (extension allowlist + percent-encoding checks + component validation), which matches common prevention guidance. ([Docs.rs][2])
* **DoS controls exist at multiple layers**: concurrency limit, render semaphore, IPFS semaphore, plus per-IP and per-key rate limiting (OWASP recommends rate limiting as a primary mitigation for API resource exhaustion). ([OWASP Cheat Sheet Series][1])
* **SVG safety is better than “typical”**: no external href resolution, and you *explicitly* validate data-URL images inside SVG using `image_href_resolver.resolve_data`, which is exactly where usvg routes data-URL fetches. ([Docs.rs][3])
* **Theming fix looks correct** and is now compatible with how Kanaria parts declare theme sources (per-part `data-theme_color_*` sources → replace with token theme values). Your current approach is structurally right.

### The two highest leverage remaining improvements

1. **Rate limiter cleanup behavior can be used to burn CPU** under high-cardinality attack patterns (distributed IPs, or bad proxy trust config). This is the single most “audit-team-unanimous” item.
2. **Default pixel limits may be too permissive for a small droplet**, especially if you end up approving a collection with big embedded rasters or large canvases. Not a functional bug—an operational risk knob.

**Release readiness call:**

* If you’re running behind Cloudflare/Nginx with sane upstream timeouts and you keep approvals curated, I’d consider this **production-viable now**, with the rate-limiter optimization strongly recommended as the first follow-up.

---

# Auditor reports

## 1) Security expert report

### Strengths (keep)

* **SSRF defense-in-depth is excellent**

  * `redirect::Policy::none()` blocks redirect-based SSRF pivots (good).
  * You resolve DNS and **reject private/loopback/link-local** IPs, then **pin the resolved IP into the request** (DNS rebinding mitigation pattern).
  * You block `http://` unless explicitly enabled and disallow private networks unless explicitly enabled.
  * This matches OWASP SSRF prevention recommendations (input validation + deny private ranges + no redirects + consider DNS rebinding). ([OWASP Cheat Sheet Series][1])
* **SVG external resource blocking is correct**

  * You disable `resolve_string` for `image_href_resolver`.
  * You also validate `resolve_data` for embedded data-URL images (rarely done, very good). usvg’s `ImageHrefResolver` is indeed the hook used for `data:` URLs. ([Docs.rs][3])
* **Static file serving (landing) is hardened**

  * Extension allowlist + traversal checks align with standard path traversal prevention guidance. ([Docs.rs][2])
* **Admin endpoints are properly isolated**

  * Admin auth is required (bearer token), rate-limited, and you use strict CSP headers for the admin UI (no inline script, no remote sources).
  * You also mark Authorization headers as sensitive in the trace layer.

### Findings

#### High: Rate limiter cleanup can be exploited for CPU burn

**Where:** `src/rate_limit.rs`
**Why it matters:** `HashMap::retain` is **O(n)**. When the map hits `max_entries` (e.g., 10k), you do a retain pass *inside the hot path* when inserting a new identity. If an attacker keeps the limiter “full” with non-expired entries, you can end up doing an O(10k) scan repeatedly.

**Attack shape:**

* Distributed requests from many IPs (or spoofed IPs if proxy trust is misconfigured).
* Keep `counters.len() == max_entries` and entries not expiring.
* Every new identity attempt triggers repeated full-map scans.

**Fix options (choose one):**

* **Best pragmatic fix:** only do `retain` **on a schedule**, not on every request (e.g., keep `last_cleanup: Instant`, and only cleanup if `now - last_cleanup > cleanup_interval`).
* Or: switch to a **TTL cache** crate (moka, lru_time_cache, etc.).
* Or: implement **random eviction** when full (cheap, not perfect) + periodic cleanup.

This is both a security and performance issue.

**Status: Fixed.**

**Fix applied:** rate limiter cleanup now runs on a fixed interval (30s), not every insert, and only when the map is full. This removes the O(n) `retain` from the hot path.

#### Medium: Defaults might allow high memory spikes

You’ve added checks for embedded raster data in SVG and you cap canvas pixels, but the defaults (`MAX_CANVAS_PIXELS=50,000,000`, etc.) can still be too high for a small machine if a “big” NFT slips into an approved collection.

**Fix option:** reduce defaults and override per deployment/collection.

**Status: Fixed.**

**Fix applied:** default limits lowered to `MAX_CANVAS_PIXELS=16,000,000`, `MAX_DECODED_RASTER_PIXELS=16,000,000`, `MAX_TOTAL_RASTER_PIXELS=64,000,000` in config defaults and `env.example`/README.

#### Low: Clarify semantics of *_PUBLIC flags

Right now the “*_PUBLIC” flags mainly determine whether those routes bypass access gating, rather than “disable the route entirely.” That’s fine—just make sure README and operators understand that distinction.

**Status: Fixed.**

**Fix applied:** README now clarifies `*_PUBLIC` flags bypass access gating only.

---

## 2) Performance expert report

### Strengths (keep)

* **Pipeline is cache-first** and has a good intermediate “composite cache” to avoid recompositing layers.
* **Concurrency control is well layered**

  * HTTP-level concurrency limit
  * Render semaphore
  * IPFS/HTTP semaphores
* **CPU-heavy work is correctly pushed to `spawn_blocking`** for raster decode, svg rasterization, and encoding.
* **No-image compression predicate** avoids wasting CPU compressing already-compressed images.

### Findings / opportunities

#### High: Rate limiter cleanup hot-path cost

Same issue as Security; it directly impacts throughput under load.

**Status: Fixed.**

#### Medium: Consider tightening pixel limits by default

Even with good code, operational defaults determine whether you OOM under “unexpected big art.”

Concretely, memory risk roughly scales with:

* `canvas_width * canvas_height * 4 bytes` for an RGBA canvas (plus overhead).
* raster intermediates and resvg surfaces can add overhead.

If the product target is **“small droplet”**, a default like:

* `MAX_CANVAS_PIXELS` ~ **16,000,000** (e.g., 4000x4000)
* `MAX_DECODED_RASTER_PIXELS` ~ **16,000,000**
* `MAX_TOTAL_RASTER_PIXELS` ~ **64,000,000**
  …is more realistic, and you can bump per deployment.

**Status: Fixed.**

**Fix applied:** defaults were tightened to the suggested range (see Security section).

#### Medium: `derive_canvas_from_asset` does SVG parsing on the async thread

This is not in `spawn_blocking`, so a cold miss on canvas sizing can block a runtime worker briefly. It’s probably rare, but it’s one of the remaining “async hygiene” improvements.

**Fix:** move the parsing work into `spawn_blocking` the same way rasterize does.

**Status: Already addressed.**

**Notes:** canvas derivation runs inside `spawn_blocking` when fetching base assets.

#### Low: Add server-side cache hit metrics

You already have a strong caching strategy. The next step is observability:

* cache hit rate (final + composite + raw asset)
* render queue wait time
* per-route latency p50/p95/p99

Even lightweight counters help you size hardware correctly. If we can somehow also nicely graph this in the admin UI, even better.

**Status: Fixed (baseline metrics).**

**Fix applied:** `/status` now reports 1h cache hit/miss totals and hit-rate when usage tracking is enabled.

---

## 3) UX expert report

This is an API-first product, so “UX” is mostly **integrator experience** + **failure-mode clarity** + **perceived performance**.

### Strengths

* Clear JSON error shapes.
* Canonical/legacy route support reduces breakage.
* Placeholder responses reduce broken-image UX.

### Findings / improvements

#### Medium: Rate limit responses should help the client recover

OWASP points to rate limiting as a core mitigation for API DoS/resource exhaustion. ([OWASP Cheat Sheet Series][1])
You already 429; make it more usable:

**Add headers on 429:**

* `Retry-After: <seconds>`
* optionally `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`

This improves both human debugging and bot behavior.

**Status: Fixed.**

**Fix applied:** 429 responses now include `Retry-After` plus `X-RateLimit-Limit/Remaining/Reset`.

#### Medium: The “cache” query requirement is powerful but sharp-edged

If some marketplaces/wallets don’t send `cache`, they’ll unintentionally force `Cache-Control: no-store` and increase load.

Fix: introduce a config switch `DEFAULT_CACHE_TTL_SECONDS` that applies when `cache` is omitted (still allow opt-out). Default will be 1 week.

**Status: Fixed.**

**Fix applied:** added `DEFAULT_CACHE_TTL_SECONDS` and made cache-control respect it when `cache` is omitted.

#### Low: Add a “rendered vs placeholder” hint header

When a placeholder is returned due to missing parts / errors, consider returning:

* `X-Renderer-Result: placeholder|rendered`
  This helps integrators decide whether to retry or show a fallback.

**Status: Fixed.**

**Fix applied:** responses now include `X-Renderer-Result` (`rendered` or `placeholder`).

---

## 4) DX expert report

### Strengths

* README is substantive and operationally oriented.
* Spec-docs are clear (and FIX3 documents the theming reasoning well).
* OpenAPI exists and is maintained.

### Findings / improvements

#### Medium: Document “deployment profiles”

Add a small doc section with recommended config presets:

* **Local dev** (open mode, approvals off)
* **Staging** (key required, openapi off, permissive limits)
* **Prod** (approvals on, key or allowlist, strict limits)

**Status: Fixed.**

**Fix applied:** added a deployment profiles section in README.

#### Medium: CI checks

Even if vendor is used in your release process, add CI steps:

* `cargo fmt --check`
* `cargo clippy`
* `cargo test`
* `cargo audit` (or `cargo deny`) as a scheduled workflow

**Status: Fixed.**

**Fix applied:** added a CI workflow for `fmt`/`clippy`/`test`, plus a scheduled `cargo audit` job.

#### Low: “Operator gotchas” callouts

One page titled “Common footguns”:

* `TRUSTED_PROXY_CIDRS` misconfiguration implications
* `ALLOW_PRIVATE_NETWORKS` danger
* `ALLOW_HTTP` danger

**Status: Fixed.**

**Fix applied:** added a “Common footguns” section in README.

---

## 5) Edge case master report

### High: Rate limiter + proxy trust can create weird failure modes

If the renderer is behind a proxy/load balancer but `TRUSTED_PROXY_CIDRS` isn’t set correctly, you can end up with:

* all requests appearing from the proxy IP → over-throttling legitimate traffic
* or if set too broadly → clients spoof IPs → bypass denylist/rate-limits

This is a classic “works in staging, fails in prod” footgun.

**Mitigation:**

* Startup warning if `TRUSTED_PROXY_CIDRS` contains very broad ranges.
* Status page could display “remote addr vs derived client ip” samples in admin-only view.

**Status: Partially addressed.**

**Fix applied:** added startup warnings for overly broad `TRUSTED_PROXY_CIDRS`. Admin IP sampling remains optional.

### Medium: Chain reorg / approval sync edge

You track approvals via events + periodic sync. Consider explicitly defining:

* confirmation depth / reorg buffer (e.g., only treat logs as final after N blocks) (per chain config - usually 5 blocks is enough across the board)
* what happens if an approval is removed during a reorg window (remove it)

Not urgent, but worth hardening.

**Status: Partially addressed.**

**Notes:** approval watcher already applies a confirmation depth (`APPROVAL_CONFIRMATIONS`). Explicit reorg handling beyond that is still optional.

### Medium: Cache-bypass via varying `cache` timestamps

You validate `cache` format and have cache size limits + eviction, which is good. Still, with public access, an attacker can generate more churn:

* many unique `cache` values across many tokens → force new variant keys

Your `max_variants_per_token` helps per token; consider also:

* per-client “new cache key per minute” limits
* or refuse “cache” timestamps that are too far in the future/past (optional)

**Status: Deferred (optional hardening).**

**Notes:** current validation + per-token variant caps mitigate abuse; additional per-client throttles remain optional.

### Low: Slowloris / connection-level DoS if deployed without a reverse proxy

If you’re not behind a reverse proxy, consider adding:

* keepalive/read timeouts at the edge (usually best solved by nginx/Cloudflare)
* HTTP server timeouts if needed

**Status: Deferred (operational).**

**Notes:** best handled at the proxy/edge layer; renderer remains compatible with upstream timeouts.

---

[1]: https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html "Server Side Request Forgery Prevention - OWASP Cheat Sheet Series"
[2]: https://docs.rs/usvg/latest/usvg/struct.Options.html "Options in usvg - Rust"
[3]: https://docs.rs/usvg/latest/usvg/struct.ImageHrefResolver.html "ImageHrefResolver in usvg - Rust"
